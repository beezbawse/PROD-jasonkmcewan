import React from 'react';
import { Button } from './Button';
import { ArrowRight, CheckCircle } from 'lucide-react';

export const Hero: React.FC = () => {
  return (
    <section id="home" className="relative pt-28 pb-20 lg:pt-36 lg:pb-32 overflow-hidden bg-gradient-to-b from-gray-50 to-white">
      
      {/* Marquee Background */}
      <div className="absolute top-32 left-0 w-full opacity-5 select-none pointer-events-none overflow-hidden whitespace-nowrap">
        <div className="animate-marquee inline-block font-heading font-black text-[8rem] lg:text-[12rem] text-navy-900 leading-none">
          TECH SUPPORT AUTOMATION GROWTH TECH SUPPORT AUTOMATION GROWTH
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-teal-50 rounded-full text-teal-700 text-sm font-bold mb-8 border border-teal-100 animate-fade-in-up">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-teal-500"></span>
            </span>
            Available for New Clients
          </div>
          
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-heading font-bold text-navy-900 mb-6 leading-tight tracking-tight">
            The <span className="text-teal-500 relative">Tech Guy
              <svg className="absolute w-full h-3 -bottom-1 left-0 text-teal-200 -z-10" viewBox="0 0 100 10" preserveAspectRatio="none">
                <path d="M0 5 Q 50 10 100 5" stroke="currentColor" strokeWidth="8" fill="none" />
              </svg>
            </span> for Entrepreneurs
          </h1>
          
          <p className="text-xl text-gray-600 mb-10 leading-relaxed max-w-2xl mx-auto">
            Leave the tech stuff of your business to a trusted expert so you can focus on what actually makes your business grow.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            <Button href="#contact" className="w-full sm:w-auto group">
              Book Your Free Consultation
              <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button variant="outline" href="#services" className="w-full sm:w-auto">
              View Services
            </Button>
          </div>

          <div className="flex flex-col sm:flex-row justify-center items-center gap-6 text-sm text-gray-500 font-medium">
            <div className="flex items-center gap-2">
              <CheckCircle size={16} className="text-teal-500" />
              <span>18 Years Experience</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle size={16} className="text-teal-500" />
              <span>Tailored Solutions</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle size={16} className="text-teal-500" />
              <span>100% Reliable</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};