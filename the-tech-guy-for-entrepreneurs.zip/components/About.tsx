import React from 'react';

export const About: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-navy-900 text-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-white/5 skew-x-12 transform origin-bottom-left pointer-events-none"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          
          <div className="w-full lg:w-1/2">
            <div className="relative">
              <div className="absolute -top-4 -left-4 w-24 h-24 bg-teal-500 rounded-tl-3xl -z-10"></div>
              <div className="absolute -bottom-4 -right-4 w-24 h-24 border-2 border-teal-500 rounded-br-3xl -z-10"></div>
              <img 
                src="https://picsum.photos/600/800" 
                alt="Jason K. McEwan" 
                className="rounded-lg shadow-2xl w-full h-auto object-cover grayscale hover:grayscale-0 transition-all duration-500"
              />
            </div>
          </div>

          <div className="w-full lg:w-1/2">
            <h2 className="text-sm font-bold text-teal-400 uppercase tracking-widest mb-2">About Me</h2>
            <h3 className="text-3xl md:text-4xl font-heading font-bold mb-8 leading-tight">
              I speak fluent "Tech", so you don't have to.
            </h3>
            <div className="space-y-6 text-gray-300 text-lg leading-relaxed">
              <p>
                With over 18 years in the technology sector, I've seen every error message, server crash, and software glitch imaginable. But more importantly, I understand the unique pressure of running a small business.
              </p>
              <p>
                I realized early on that most entrepreneurs didn't start their companies to manage DNS records or debug API integrations. They started them to share their passion with the world.
              </p>
              <p>
                My mission is simple: I act as your dedicated technical partner. I take the complex, frustrating tech problems off your plate and turn them into silent, efficient systems that power your growth.
              </p>
            </div>
            
            <div className="mt-10 pt-10 border-t border-white/10 flex flex-row gap-12">
              <div>
                <span className="block text-4xl font-bold text-white mb-1">18+</span>
                <span className="text-sm text-teal-400 uppercase tracking-wider">Years Exp.</span>
              </div>
              <div>
                <span className="block text-4xl font-bold text-white mb-1">200+</span>
                <span className="text-sm text-teal-400 uppercase tracking-wider">Projects</span>
              </div>
              <div>
                <span className="block text-4xl font-bold text-white mb-1">100%</span>
                <span className="text-sm text-teal-400 uppercase tracking-wider">Satisfaction</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};