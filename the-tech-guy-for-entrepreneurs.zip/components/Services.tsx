import React from 'react';
import { Workflow, Cable, LifeBuoy } from 'lucide-react';
import { Button } from './Button';

interface ServiceCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ icon, title, description }) => (
  <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300 flex flex-col items-start group h-full">
    <div className="w-14 h-14 bg-navy-50 rounded-xl flex items-center justify-center text-navy-900 group-hover:bg-teal-500 group-hover:text-white transition-colors duration-300 mb-6 shrink-0">
      {icon}
    </div>
    <h3 className="text-2xl font-heading font-bold text-navy-900 mb-4">{title}</h3>
    <p className="text-gray-600 leading-relaxed mb-8 flex-grow">{description}</p>
    <Button href="#contact" variant="outline" className="w-full sm:w-auto">
      Book Consultation
    </Button>
  </div>
);

export const Services: React.FC = () => {
  const services = [
    {
      icon: <Workflow size={32} />,
      title: "Automation",
      description: "Stop doing repetitive tasks manually. I build streamlined workflows that handle administrative busywork like data entry, invoice processing, and scheduling appointments automatically, giving you back hours every week to focus on strategy."
    },
    {
      icon: <Cable size={32} />,
      title: "Software Integrations",
      description: "Make your tools talk to each other. I seamlessly connect your essential platforms—linking your CRM to email marketing or your e-commerce store to accounting software—so data flows smoothly without manual entry errors."
    },
    {
      icon: <LifeBuoy size={32} />,
      title: "Ongoing Tech Support",
      description: "Never stress about technical glitches again. From resolving server crashes and plugin conflicts to handling security updates and email migrations, my reliable support ensures your business runs at peak performance."
    }
  ];

  return (
    <section id="services" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-teal-600 uppercase tracking-widest mb-2">My Expertise</h2>
          <h3 className="text-3xl md:text-4xl font-heading font-bold text-navy-900">How I Help You Scale</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard key={index} {...service} />
          ))}
        </div>
      </div>
    </section>
  );
};