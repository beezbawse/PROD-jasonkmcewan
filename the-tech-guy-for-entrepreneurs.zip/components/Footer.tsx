import React from 'react';
import { Code2 } from 'lucide-react';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-navy-900 text-white pt-16 pb-8 border-t border-navy-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center mb-12">
          <div className="flex items-center gap-2 mb-4 md:mb-0">
             <div className="w-8 h-8 bg-teal-500 text-white rounded flex items-center justify-center">
                <Code2 size={20} />
              </div>
            <div>
              <span className="font-heading font-bold text-xl">Jason K. McEwan</span>
              <span className="block text-xs text-gray-400">The Tech Guy For Entrepreneurs</span>
            </div>
          </div>
          
          <div className="flex gap-8">
            <a href="#home" className="text-gray-400 hover:text-teal-400 transition-colors text-sm">Home</a>
            <a href="#services" className="text-gray-400 hover:text-teal-400 transition-colors text-sm">Services</a>
            <a href="#about" className="text-gray-400 hover:text-teal-400 transition-colors text-sm">About</a>
            <a href="#contact" className="text-gray-400 hover:text-teal-400 transition-colors text-sm">Contact</a>
          </div>
        </div>
        
        <div className="border-t border-navy-800 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-gray-500">
          <p>&copy; {currentYear} Jason K. McEwan. All rights reserved.</p>
          <div className="flex gap-4 mt-4 md:mt-0">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};