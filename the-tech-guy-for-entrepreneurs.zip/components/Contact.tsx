import React, { useState, useEffect } from 'react';
import { Button } from './Button';
import { Mail, Linkedin } from 'lucide-react';

export const Contact: React.FC = () => {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    phone: '',
    companyName: '',
    businessSize: '1-10',
    message: ''
  });

  useEffect(() => {
    // Load the Google Calendar script
    const script = document.createElement('script');
    script.src = "https://calendar.google.com/calendar/scheduling-button-script.js";
    script.async = true;
    script.onload = () => {
      // Initialize the button once script is loaded
      // @ts-ignore
      if (window.calendar && window.calendar.schedulingButton) {
        // @ts-ignore
        window.calendar.schedulingButton.load({
          url: 'https://calendar.google.com/calendar/appointments/schedules/AcZssZ2YnsyIZie1d_GvtHk9v7K_wmt9tKtjxclrQ0SIA0FiqmHzhnZB29ms7RVEggtpBKtV5W9AZp1n?gv=true',
          color: '#14b8a6', // Brand Teal
          label: 'Book Your Free 30-Minute Consultation',
          target: document.getElementById('google-calendar-button-target')
        });
      }
    };
    document.body.appendChild(script);

    return () => {
      document.body.removeChild(script);
    };
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormState({
      ...formState,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulation of form submission
    alert("Thank you for your interest! This is a demo site, but in production, this would send your details to Jason.");
  };

  return (
    <section id="contact" className="py-24 bg-gray-50">
      <style>{`
        #google-calendar-button-target .calendar-scheduling-button {
          font-family: 'Roboto', sans-serif !important;
          font-weight: 500 !important;
          font-size: 1rem !important;
          border-radius: 0.375rem !important; /* Match rounded-md */
        }
      `}</style>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto bg-white rounded-3xl shadow-2xl overflow-hidden">
          <div className="flex flex-col md:flex-row">
            
            {/* Left Side: Content */}
            <div className="w-full md:w-2/5 bg-navy-900 text-white p-10 flex flex-col justify-between">
              <div>
                <h3 className="text-3xl font-heading font-bold mb-6">Ready to Reclaim Your Time?</h3>
                <p className="text-teal-100 mb-8 leading-relaxed">
                  Let's discuss your current tech headaches and how we can solve them. Book a free 30-minute consultation to see if we're a good fit.
                </p>
                
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center text-teal-400 shrink-0">
                      <Mail size={20} />
                    </div>
                    <a href="mailto:contact@jasonkmcewan.com" className="hover:text-teal-400 transition-colors break-all">contact@jasonkmcewan.com</a>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center text-teal-400 shrink-0">
                      <Linkedin size={20} />
                    </div>
                    <a href="https://www.linkedin.com/in/jason-k-mcewan/" target="_blank" rel="noopener noreferrer" className="hover:text-teal-400 transition-colors">/in/jason-k-mcewan</a>
                  </div>
                </div>
              </div>
              
              <div className="mt-12">
                <p className="text-sm text-gray-400 mb-4">
                  Prefer a direct calendar booking?
                </p>
                <div id="google-calendar-button-target"></div>
              </div>
            </div>

            {/* Right Side: Form */}
            <div className="w-full md:w-3/5 p-10">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label htmlFor="name" className="text-sm font-bold text-navy-900">Full Name</label>
                    <input 
                      type="text" 
                      id="name" 
                      name="name" 
                      value={formState.name}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 outline-none transition-all"
                      placeholder="John Doe"
                      required 
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-bold text-navy-900">Email Address</label>
                    <input 
                      type="email" 
                      id="email" 
                      name="email" 
                      value={formState.email}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 outline-none transition-all"
                      placeholder="john@company.com"
                      required 
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label htmlFor="companyName" className="text-sm font-bold text-navy-900">Company Name</label>
                    <input 
                      type="text" 
                      id="companyName" 
                      name="companyName" 
                      value={formState.companyName}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 outline-none transition-all"
                      placeholder="Your Business Name"
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="phone" className="text-sm font-bold text-navy-900">Phone Number</label>
                    <input 
                      type="tel" 
                      id="phone" 
                      name="phone" 
                      value={formState.phone}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 outline-none transition-all"
                      placeholder="(555) 123-4567"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label htmlFor="businessSize" className="text-sm font-bold text-navy-900">Business Size</label>
                  <div className="relative">
                    <select 
                      id="businessSize" 
                      name="businessSize" 
                      value={formState.businessSize}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 outline-none transition-all appearance-none text-gray-600"
                    >
                      <option value="1-10">1-10 Employees</option>
                      <option value="11-25">11-25 Employees</option>
                      <option value="26-50">26-50 Employees</option>
                      <option value="51+">51+ Employees</option>
                    </select>
                    <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                      <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label htmlFor="message" className="text-sm font-bold text-navy-900">How can I help?</label>
                  <textarea 
                    id="message" 
                    name="message" 
                    value={formState.message}
                    onChange={handleChange}
                    rows={4} 
                    className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 outline-none transition-all"
                    placeholder="Tell me about your biggest tech frustration..."
                  ></textarea>
                </div>

                <Button type="submit" className="w-full">
                  Send Message
                </Button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};