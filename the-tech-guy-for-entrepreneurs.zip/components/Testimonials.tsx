import React from 'react';
import { Quote } from 'lucide-react';

interface TestimonialProps {
  name: string;
  role: string;
  location: string;
  quote: string;
}

const TestimonialCard: React.FC<TestimonialProps> = ({ name, role, location, quote }) => (
  <div className="bg-gray-50 p-8 rounded-2xl border border-gray-100 relative">
    <Quote className="absolute top-6 right-6 text-teal-100 rotate-180" size={48} />
    <p className="text-gray-700 italic text-lg mb-6 relative z-10">"{quote}"</p>
    <div>
      <h4 className="font-bold text-navy-900">{name}</h4>
      <p className="text-sm text-teal-600 font-medium">{role}</p>
      <p className="text-xs text-gray-400">{location}</p>
    </div>
  </div>
);

export const Testimonials: React.FC = () => {
  const testimonials = [
    {
      name: "Sarah Jenkins",
      role: "Owner, Bloom Floral Studio",
      location: "Oakville, ON",
      quote: "Before Jason, I spent 2 hours a day just trying to get my order system to sync with my inventory. He fixed it in a week. I've reclaimed 10 hours a week and my stress levels have plummeted."
    },
    {
      name: "Michael Chen",
      role: "Founder, Chen Consulting Group",
      location: "Kitchener, ON",
      quote: "The automation Jason set up for our client onboarding process is seamless. We look more professional, and we haven't missed a follow-up email since. Business growth has actually become manageable."
    },
    {
      name: "Elena Rodriguez",
      role: "CEO, Artisan Eats",
      location: "Charlottetown, PEI",
      quote: "I was terrified of hiring a tech person because I didn't know what I needed. Jason explained everything in plain English and only implemented what actually helped my bottom line. Worth every penny."
    }
  ];

  return (
    <section id="testimonials" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-teal-600 uppercase tracking-widest mb-2">Success Stories</h2>
          <h3 className="text-3xl md:text-4xl font-heading font-bold text-navy-900">Don't Just Take My Word For It</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, i) => (
            <TestimonialCard key={i} {...t} />
          ))}
        </div>
      </div>
    </section>
  );
};